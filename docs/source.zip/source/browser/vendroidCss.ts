/*
 * VendroidEnhanced static build integration
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

declare global {
    interface Window {
        __vendroidMathCss?: string;
    }
}

let initialized = false;

/** The Android bridge is supplied by the APK, never by this build. */
export function getVendroidRendererCss(): string | undefined {
    if (!window.VencordMobileNative || typeof window.__vendroidMathCss !== "string")
        return undefined;

    if (!initialized) {
        initialized = true;
        const removeStockCss = () => {
            for (const link of document.querySelectorAll<HTMLLinkElement>("link[rel='stylesheet']")) {
                if (/^https:\/\/vde-builds\.nin0\.dev\/(?:vencord|equicord)\/browser\.css(?:[?#].*)?$/.test(link.href))
                    link.remove();
            }
        };
        removeStockCss();
        // The APK adds stock CSS after this bundle, during DOMContentLoaded.
        const observer = new MutationObserver(removeStockCss);
        observer.observe(document, { childList: true, subtree: true });
        const finish = () => setTimeout(() => {
            removeStockCss();
            observer.disconnect();
        }, 0);
        if (document.readyState === "loading")
            document.addEventListener("DOMContentLoaded", finish, { once: true });
        else
            finish();
    }
    return window.__vendroidMathCss;
}
