const test = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const esbuild = require('esbuild');

async function host(css, bridge = true) {
    const build = await esbuild.build({entryPoints:['browser/VencordNativeStub.ts'],bundle:true,write:false,platform:'node',format:'cjs',define:{IS_USERSCRIPT:'false'},plugins:[{name:'isolate-host',setup(b){
        b.onResolve({filter:/^(file:|@)/},a=>({path:a.path,namespace:'host'}));
        b.onLoad({filter:/.*/,namespace:'host'},a=>({contents:a.path.startsWith('file:')?'export default ""':'export const EXTENSION_BASE_URL="", RENDERER_CSS_URL="", metaReady=new Promise(()=>{}), localStorage={getItem(){return null}}; export const debounce=f=>f; export const createStore=()=>({}); export const get=async()=>undefined,set=async()=>{},del=async()=>{},entries=async()=>[]; export function getThemeInfo(){}; export function getStylusWebStoreUrl(){};',loader:'js'}));
    }}]});
    const stock={href:'https://vde-builds.nin0.dev/vencord/browser.css',removed:false,remove(){this.removed=true}};
    const custom={href:'https://example.org/my.css',removed:false,remove(){this.removed=true}};
    const links=[stock,custom]; const events={}; const observers=[];
    const doc={readyState:'loading',querySelectorAll(){return links.filter(x=>!x.removed)},addEventListener(n,f){events[n]=f}};
    const window={__vendroidMathCss:css}; if(bridge)window.VencordMobileNative={};
    class Observer{constructor(f){this.f=f;this.disconnected=false;observers.push(this)}observe(){}disconnect(){this.disconnected=true}}
    const ctx={window,document:doc,MutationObserver:Observer,setTimeout,clearTimeout,console,exports:{},module:{exports:{}},fetch(){throw new Error('no CSS fetch allowed')}};
    vm.createContext(ctx);vm.runInContext(build.outputFiles[0].text,ctx);
    return {ctx,stock,custom,events,observers,links};
}
test('bundled mobile CSS resolves without extension metadata or fetch', async()=>{
    const h=await host('.bm-enhanced-content{color:red}');
    const result=await Promise.race([h.ctx.window.VencordNative.native.getRendererCss(),new Promise(r=>setTimeout(()=>r('TIMEOUT'),50))]);
    assert.equal(result,'.bm-enhanced-content{color:red}');
    assert.equal(h.stock.removed,true);
    assert.equal(h.custom.removed,false);
    const added={href:'https://vde-builds.nin0.dev/equicord/browser.css',removed:false,remove(){this.removed=true}};h.links.push(added);h.observers[0].f([]);assert.equal(added.removed,true);
    h.events.DOMContentLoaded();await new Promise(r=>setTimeout(r,10));assert.equal(h.observers[0].disconnected,true);
});
test('ordinary web client never consumes mobile CSS or removes links',async()=>{
    const h=await host('.private-css{}',false);
    const result=await Promise.race([h.ctx.window.VencordNative.native.getRendererCss(),new Promise(r=>setTimeout(()=>r('PENDING_METADATA'),30))]);
    assert.equal(result,'PENDING_METADATA');assert.equal(h.stock.removed,false);assert.equal(h.observers.length,0);
});
