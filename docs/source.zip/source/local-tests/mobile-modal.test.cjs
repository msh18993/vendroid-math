const test = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const esbuild = require('esbuild');
const path = require('node:path');

test('developer settings use the shipped modern modal and retain custom URL controls', async () => {
    const built = await esbuild.build({
        entryPoints: [path.resolve('src/plugins/vendroidEnhancements/settings/components/DevOptions.tsx')],
        bundle: true, write: false, platform: 'node', format: 'cjs', jsxFactory: '__jsx',
        plugins: [{ name: 'host-boundaries', setup(build) {
            build.onResolve({filter: /^@|^\.\.\//}, args => ({path: args.path, namespace: 'host'}));
            build.onLoad({filter: /.*/, namespace: 'host'}, args => {
                let contents;
                if (args.path === '@webpack/common') contents = 'export const Modal="modern-modal"; export function openModal(f){globalThis.render=f}';
                else if (args.path === '@utils/modal') contents = 'export const ModalRoot="legacy-modal",ModalHeader="header",ModalContent="content",ModalCloseButton="close",ModalSize={DYNAMIC:"dynamic"}; export function openModal(f){globalThis.render=f}';
                else if (args.path === '@components/index') contents = 'export const ErrorBoundary="error-boundary",BaseText="text"';
                else if (args.path.endsWith('generateOptions')) contents = 'export const generateOptions=x=>Object.values(x).map(s=>({label:s.label,type:s.type}))';
                else if (args.path.endsWith('/utils')) contents = 'export const cl=x=>x';
                else contents = 'export {}';
                return {contents,loader:'js'};
            });
        }}]
    });
    const ctx = {React: {Fragment:'fragment'}, exports: {}, module: {exports:{}}, __jsx: (type, props, ...children) => ({type,props:props||{},children})};
    vm.createContext(ctx);
    vm.runInContext(built.outputFiles[0].text,ctx);
    ctx.module.exports.showDevOptionsModal();
    const result = ctx.render({onClose:()=>{},transitionState:1});
    const nodes=[]; const walk=n=>{if(!n||typeof n!=='object')return;if(n.type)nodes.push(n);for(const c of n.children||[])Array.isArray(c)?c.forEach(walk):walk(c)}; walk(result);
    const modal=nodes.find(n=>n.type==='modern-modal');
    assert.ok(modal,'shipped Modal component must be used rather than removed legacy components');
    assert.equal(modal.props.title,'Developer settings');
    assert.equal(typeof modal.props.onClose,'function');
    assert.match(JSON.stringify(result),/Vencord location/);
    assert.match(JSON.stringify(result),/Allow remote debugging/);
});
