const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const cp=require('node:child_process');const path=require('node:path');const vm=require('node:vm');
test('publishable mobile JS contains matching CSS and no sourcemap references',()=>{
 const out=path.resolve('local-tests/package-output');const run=cp.spawnSync(process.execPath,['scripts/packageVendroid.mjs','--out',out],{encoding:'utf8'});assert.equal(run.status,0,run.stderr);
 const js=fs.readFileSync(path.join(out,'browser.js'),'utf8');const css=fs.readFileSync(path.join(out,'browser.css'),'utf8');assert.ok(!js.includes('sourceMappingURL='));assert.ok(!css.includes('sourceMappingURL='));
 const prefix=js.split('/* VENDROID_RUNTIME_START */')[0];const ctx={window:{}};vm.createContext(ctx);vm.runInContext(prefix,ctx);assert.equal(ctx.window.__vendroidMathCss,css);assert.ok(css.includes('.bm-enhanced-content'));assert.ok(css.includes('border-bottom:none!important'));assert.ok(!css.includes(':hover .panel__5dec7'));
 assert.ok(fs.existsSync(path.join(out,'browser.js.LEGAL.txt')));const manifest=JSON.parse(fs.readFileSync(path.join(out,'build.json'),'utf8'));assert.ok(manifest.sha256['browser.js']);assert.equal(manifest.deviceVerified,false);
});
