/* SPDX-License-Identifier: GPL-3.0-or-later */
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';

const args=process.argv.slice(2);
if(args.length!==0 && !(args.length===2 && args[0]==='--out')) throw new Error('Usage: node scripts/packageVendroid.mjs [--out directory]');
const out=resolve(args[1]??'../publish/docs');
await mkdir(out,{recursive:true});
const stripMap=s=>s.replace(/^\/\/[#@] sourceMappingURL=.*$/gm,'').replace(/\/\*[#@] sourceMappingURL=[\s\S]*?\*\//g,'');
let css=stripMap(await readFile('dist/browser.css','utf8'));
// Only the established clean-heading preference, never desktop hover/sidebar CSS.
css+='\n.bm-enhanced-content .bm-heading-1,.bm-enhanced-content .bm-heading-2{border-bottom:none!important;padding-bottom:0!important}\n';
const commit=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim();
const metadata={id:'20261027-2',vencordCommit:commit,deviceVerified:false};
const prefix='/*! VendroidEnhanced math build. GPL-3.0-or-later; corresponding source: source.zip; notices: browser.js.LEGAL.txt */\n'+
 'window.__vendroidMathCss='+JSON.stringify(css)+';\nwindow.__vendroidMathBuild=Object.freeze('+JSON.stringify(metadata)+');\n/* VENDROID_RUNTIME_START */\n';
const js=prefix+stripMap(await readFile('dist/browser.js','utf8'));
await writeFile(resolve(out,'browser.js'),js);
await writeFile(resolve(out,'browser.css'),css);
await writeFile(resolve(out,'browser.js.LEGAL.txt'),await readFile('dist/browser.js.LEGAL.txt'));
const sha256={};for(const name of ['browser.js','browser.css','browser.js.LEGAL.txt'])sha256[name]=createHash('sha256').update(await readFile(resolve(out,name))).digest('hex');
await writeFile(resolve(out,'build.json'),JSON.stringify({...metadata,sha256},null,2)+'\n');
console.log(JSON.stringify({out,...metadata,sha256},null,2));
